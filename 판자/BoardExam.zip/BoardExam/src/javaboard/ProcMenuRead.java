package javaboard;

import boarddata.Data;
import boarddata.Post;
import util.Ci;

public class ProcMenuRead {
	static void run() {
		System.out.println("글 읽기 입니다.");
		String cmd = Ci.r("읽을 글 번호");
		for(Post p:Data.posts) {
			if(cmd.equals(p.instanceNo+"")) {
				p.infoForRead();
			}
		}
	}

}
