package javaboard;

import boarddata.Data;
import util.Ci;
import util.Cw;

public class ProcMenuDel {
	static void run() {
		System.out.println("글 삭제 입니다.");
		String cmd = Ci.r("삭제 할 글 번호");

		int tempSearchIndex = 0;
		for(int i = 0; i < Data.posts.size(); i++) {
			if(cmd.equals(Data.posts.get(i).instanceNo+"")) {
				tempSearchIndex = i;
			}
		}
		Data.posts.remove(tempSearchIndex);
		Cw.wn("글 수: " +Data.posts.size());
		
	
	
	
	
	}

}
