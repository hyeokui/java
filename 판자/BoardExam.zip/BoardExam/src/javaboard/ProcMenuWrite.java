package javaboard;

import boarddata.Data;
import boarddata.Post;
import util.Ci;
import util.Cw;

public class ProcMenuWrite {
	static void run() {
		System.out.println("글 쓰기 입니다.");
		String title;
		while(true) {
			title=Ci.rl("글제목");
			if(title.length()>0) {
				break;
			}else {
				Cw.wn("입력오류");
			}
		}
		String writer;
		while(true) {
			writer=Ci.rl("작성자");
			if(writer.length()>0) {
				break;
			}else {
				Cw.wn("입력오류");
			}
		}
		String content;
		while(true) {
			content=Ci.rl("글내용");
			if(content.length()>0) {
				break;
			}else {
				Cw.wn("입력오류");
			}
		}
		
		
		Post p = new Post(title, writer, content, 0);
		Data.posts.add(p);
		Cw.wn("글 추가 완료");
			
		
		
		
		
	}
}
