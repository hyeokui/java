package javaboard;

import boarddata.Data;
import dispaly.Disp;

public class Board {
	public static final String VERSION = "v0.0.5";
	public static final String TITLE = "고양이 게시판("+VERSION+") feat. choi";
	public void run() {
		Data.loadData();
		Disp.title();
		ProcMenu.run();
	}
	

}
