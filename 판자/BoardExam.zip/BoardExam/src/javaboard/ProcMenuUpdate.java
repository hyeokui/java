package javaboard;

import boarddata.Data;
import boarddata.Post;
import util.Ci;
import util.Cw;

public class ProcMenuUpdate {
	static void run() {
		System.out.println("글 수정 입니다.");
		String cmd = Ci.r("수정 할 글 번호");
		for(Post p:Data.posts){
			if(cmd.equals(p.instanceNo+"")) {
				String content = Ci.rl("수정 할 글내용");
				p.content = content;
				Cw.wn("글 수정 완료");
			}
		}
	}

}
