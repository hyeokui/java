package javaboard;

import boarddata.Data;
import boarddata.Post;

public class ProcMenuList {
	static void run() {
		System.out.println("글 목록 입니다.");
		for(Post p:Data.posts) {
			p.infoForList();
			
		}
	}

}
