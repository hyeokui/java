package com.hyeok.c.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Db {
	static private String DB_NAME = "my_cat";
	static private String DB_ID = "root";
	static private String DB_PW = "root";
	static public Connection con = null;
	static public Statement st = null;
	static public ResultSet result = null;

	static public void dbInit() {
		try {
			Db.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + DB_NAME, DB_ID, DB_PW);
			Db.st = Db.con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet
												// 객체만을 열 수있다.
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	static public void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			if (resultCount == 0) {
				System.out.println("입력오류입니다.");
			} else {
				System.out.println("처리된 행 수:" + resultCount);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	static public void dbPostCount() {
		try {
			Db.result = Db.st.executeQuery("select count(*) from board");
			Db.result.next();
			String count = Db.result.getString("count(*)");
			System.out.println("글 수:" + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	static public int getPostCount() {
		String count = "";
		try {
			Db.result = Db.st.executeQuery("select count(*) from board");
			Db.result.next();
			count = Db.result.getString("count(*)");
//			System.out.println("글 수:"+count);  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}

	public static int getPostCountSearch(String searchWord) {
		String count = "";
		try {
			Db.result = Db.st.executeQuery("select count(*) from board where b_title like '%" + searchWord + "%'");
			Db.result.next();
			count = Db.result.getString("count(*)");
			System.out.println("글 수:" + count);
		} catch (Exception e) {
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}

	static public boolean isProcLogin(String id, String pw) {
		String count = "";// 값 담아놓을 변수
		try {
			Db.result = Db.st.executeQuery("select count(*) from member where s_id = '" + id + "' and s_pw = '" + pw + "'");// 멤버 테이블에 검색
			Db.result.next();
			count = Db.result.getString("count(*)");// 선언해놓은 count변수에 값 담아놓고
			System.out.println("찾은 회원 수: " + count);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (count.equals("1")) {// sql문으로 검색한 값이 있을시 1이므로 문자열 비교를 해준뒤 true를 리턴해준다.
			System.out.println("로그인성공");
			return true; // 로그인 성공한 값 리턴
		} else {
			System.out.println("로그인실패");
			return false;// 로그인 실패 값 리턴
		}
	}
}
