package com.hyeok.c.site;

import java.util.Scanner;

import com.hyeok.c.member.ProcMemberRegister;
import com.hyeok.c.member.ProcMenuLogin;
import com.hyeok.c.mysqlboard.ProcBoard;
import com.hyeok.c.site.display.DisplaySite;
import com.hyeok.c.util.Db;

public class SiteMain {
	
	static Scanner sc = new Scanner(System.in);
	static private String cmd = "";
	public static String loginedId = null;
	
	static public void run() {
		Db.dbInit();//접속
		DisplaySite.entranceTitle();//계속 보이면 정신사나워서 반복 안시켰음
		loop:while(true) {
			DisplaySite.showMainMenu();//선택메뉴들만 보이게 반복
			System.out.println("명령입력:");
			cmd =sc.next();
			switch(cmd) {
	
			case "r":
				ProcMemberRegister.run();//회원가입메뉴
				break;
			case "l":
				if(loginedId == null) {//기본 null값 설정 후 
					loginedId = ProcMenuLogin.run();//로그인메뉴로
				} else {
					System.out.println("로그아웃");
					loginedId = null;
				}
				break;
			case "a":
				break;
			case "e":
				System.out.println("프로그램 종료");
				break loop;
			case "b":
				System.out.println("게시판으로 이동합니다.");
				ProcBoard.run();
				break;
				default:
					System.out.println("없는 목록입니다.");
			}
		}
	}
}
