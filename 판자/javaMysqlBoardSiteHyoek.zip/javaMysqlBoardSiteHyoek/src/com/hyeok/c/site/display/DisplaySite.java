package com.hyeok.c.site.display;

import com.hyeok.c.site.SiteMain;
import com.hyeok.c.util.Cw;

public class DisplaySite {
	static private String SITE_NAME = "Hyoek";
	static private String VERSION = " v0.0.1";
	static private String FEAT = " hyeok";
	
	static public void entranceTitle() {
		Cw.line();
		Cw.dot();
		Cw.space(14);
		Cw.w(SITE_NAME);
		Cw.w(VERSION);
		Cw.w(FEAT);
		Cw.space(16);
		Cw.dot();
		Cw.wn();
		Cw.line();
	}

	static public void showMainMenu() {
		if(SiteMain.loginedId == null) {
			Cw.dot();
			Cw.w("[r]회원가입 [l]로그인 [a]관리자 [e]프로그램종료 [b]게시판(임시입구)");
			Cw.dot();
			Cw.wn();
		} else {
			Cw.wn (SiteMain.loginedId+"님 환영합니다.");
			Cw.dot();
			Cw.w("[r]회원가입 [l]로그아웃 [a]관리자 [e]프로그램종료 [b]게시판(임시입구)");
			Cw.dot();
			Cw.wn();
		}
		
	}
	
	static public void registration() {
		Cw.wn("======== 회원가입 =========");
	}
}
