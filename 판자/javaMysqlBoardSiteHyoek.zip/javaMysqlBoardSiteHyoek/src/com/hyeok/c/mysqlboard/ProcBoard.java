package com.hyeok.c.mysqlboard;

import java.util.Scanner;

import com.hyeok.c.mysqlboard.display.Display;
import com.hyeok.c.util.Db;

public class ProcBoard {
	static Scanner sc = new Scanner(System.in);

	public static void run() {
		Display.showTitle();// 첫 타이틀 모양
		Db.dbInit();// sql 연동
		System.out.println("전체 글 수: "+Db.getPostCount());
		loop: while (true) {
//			Db.dbPostCount();
			Display.showMainMenu();// 메인메뉴항목 명령끝날때마다 다시 나타나도록 반복문안에
			System.out.println("명령입력: ");
			String cmd = sc.next();
			switch (cmd) {
			case "1":
				ProcMenuList.run();// 글리스트메뉴
				break;
			case "2":
				ProcMenuRead.run();// 글읽기메뉴
				break;
			case "3":
				ProcMenuWrite.run();// 글쓰기메뉴
				break;
			case "4":
				ProcMenuDel.run();// 글삭제메뉴
				break;
			case "5":
				ProcMenuEdit.run();// 글수정메뉴
				break;
			case "6":
				ProcMenuReply.write();//댓글달기메뉴
				break;
			case "7":
				ProcMenuList.search();//글검색메뉴
				break;
			case "e":
				System.out.println("사이트 메인으로 이동");
				break loop;
			default:
				System.out.println("다시 입력해주십시오.");
				break;
			}
		}

	}

}