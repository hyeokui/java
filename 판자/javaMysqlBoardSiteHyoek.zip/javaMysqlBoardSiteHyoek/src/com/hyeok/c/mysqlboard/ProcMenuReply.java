package com.hyeok.c.mysqlboard;

import java.sql.SQLException;
import java.util.Scanner;

import com.hyeok.c.mysqlboard.display.Display;
import com.hyeok.c.util.Db;

public class ProcMenuReply {
	static Scanner sc = new Scanner(System.in);

	static public void list(int oriNo) {
		Display.replyBar();
		String sql = "select * from reply_board where b_reply_ori=" + oriNo;
		try {
//			System.out.println("전송한sql문:" + sql);
			Db.result = Db.st.executeQuery(sql);
			while (Db.result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				String b_reply_text = Db.result.getString("b_reply_text");
				System.out.println(b_reply_text);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*
	 * 댓글 작성 함수
	 */
	static public void write(int b_reply_ori) {
		System.out.println("댓글입력: ");
		String b_reply_text = sc.nextLine();
		Db.dbExecuteUpdate("insert into reply_board (b_id,b_datetime,b_reply_ori,b_reply_text) values('댓글러',now(),"
				+ b_reply_ori + ",'" + b_reply_text + "')");
	}

	static public void write() {
		System.out.println("댓글을 작성 할 글 번호를 입력하십시오:");
		String b_reply_num = sc.next();
		 int b_reply_ori = Integer.parseInt(b_reply_num);
			System.out.println("댓글입력: ");
			sc.nextLine();
			String b_reply_text = sc.nextLine();
			Db.dbExecuteUpdate("insert into reply_board (b_id,b_datetime,b_reply_ori,b_reply_text) values('댓글러',now(),"
					+ b_reply_ori + ",'" + b_reply_text + "')");

	}
}
