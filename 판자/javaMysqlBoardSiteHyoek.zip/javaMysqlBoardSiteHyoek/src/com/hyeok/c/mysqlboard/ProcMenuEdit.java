package com.hyeok.c.mysqlboard;

import java.util.Scanner;

import com.hyeok.c.util.Db;

public class ProcMenuEdit {

	static Scanner sc = new Scanner(System.in);

	static void run() {

		System.out.println("편집 할 글번호를 입력하십시오:");
		String editNo = sc.next();
		sc.nextLine();
		System.out.println("편집 할 제목을 입력하십시오:");
		String edTitle = sc.nextLine();
		System.out.println("편집자id를 입력하십시오:");
		String edId = sc.next();
		sc.nextLine();
		System.out.println("편집 할 내용을 입력하십시오:");
		String edText = sc.nextLine();

		Db.dbExecuteUpdate("update board set b_title='" + edTitle + "',b_corrector='" + edId
				+ "',b_datetime=now(),b_text='" + edText + "' where b_no=" + editNo);
	}

}