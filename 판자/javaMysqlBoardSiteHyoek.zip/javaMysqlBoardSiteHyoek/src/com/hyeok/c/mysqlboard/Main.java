package com.hyeok.c.mysqlboard;

import com.hyeok.c.site.SiteMain;

public class Main {
	public static void main(String[] args) {
		SiteMain.run();
	}
	
	

}