package com.hyeok.c.mysqlboard.display;

import com.hyeok.c.util.Cw;

public class Display {
	static private String TITLE = "고양이 게시판";
	static private String VERSION = " v0.0.8";
	static private String FEAT = " hyoek";
	
		static public void showTitle() {
			Cw.line();
			Cw.dot();
			Cw.space(14);
			Cw.w(TITLE);
			Cw.w(VERSION);
			Cw.w(FEAT);
			Cw.space(13);
			Cw.dot();
			Cw.wn();
			Cw.line();
		}
		
		static public void showMainMenu() {
			Cw.dot();
			Cw.w("[1]글리스트 [2]글읽기 [3]글쓰기 [4]글삭제 [5] 글편집 [6]댓글작성 [7]글검색 [e]게시판 종료");
			Cw.dot();
			Cw.wn();
		}
		
		static public void titleList() {
			System.out.println("==========================================");
			System.out.println("================= 글리스트 ==================");
			System.out.println("==========================================");
			System.out.println("글번호  글제목   작성자id   편집자id   작성시간");
		}
		public static void replyBar() {
			System.out.println("================= 댓글 리스트 ==================");
		}	
	}


