package com.hyeok.c.member;

import java.util.Scanner;

import com.hyeok.c.site.display.DisplaySite;
import com.hyeok.c.util.Db;

public class ProcMemberRegister {
	static Scanner sc = new Scanner(System.in);
//	static private String cmd = "";
	static public void run() {
		DisplaySite.registration();
		String id = "";
		String pw = "";
		while(true) {
			System.out.println("아이디:");
			id = sc.next();
			if(id.length()>0) {
				break;
			}else {
				System.out.println("다시 입력해주십시오.");
			}
		}
		while(true) {
			System.out.println("비밀번호:");
			pw = sc.next();
			if(pw.length()>3) {
				break;
			}else {
				System.out.println("다시 입력해주십시오.");
			}
				
		}
		Db.dbExecuteUpdate("insert into member(s_id,s_pw) values ('"+id+"','"+pw+"')");
		System.out.println("가입완료");
		
	}

}
