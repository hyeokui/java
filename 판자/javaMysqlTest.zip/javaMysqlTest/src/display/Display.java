package display;


public class Display {

		static private String TITLE_BAR = "🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈"; 
		static private String TITLE 	= "🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈     게시판     🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈🐈"; 
		
		static private String MAIN_MENU_BAR = "================================================================";
		static private String MAIN_MENU	 	= "[1]글리스트 [2]글읽기 [3]글쓰기 [4]글삭제 [5] 글편집 [6]댓글작성 [7]글검색 [e]프로그램종료";
		
		static public void showTitle() {
			System.out.println(TITLE_BAR);
			System.out.println(TITLE);
			System.out.println(TITLE_BAR);
		}
		
		static public void showMainMenu() {
			System.out.println(MAIN_MENU_BAR);
			System.out.println(MAIN_MENU);
			System.out.println(MAIN_MENU_BAR);
			
		}
		
		static public void titleList() {
			System.out.println("==========================================");
			System.out.println("================= 글리스트 ==================");
			System.out.println("==========================================");
			System.out.println("글번호  글제목   작성자id   편집자id   작성시간");
		}
		public static void replyBar() {
			System.out.println("================= 댓글 리스트 ==================");
		}	
	}


