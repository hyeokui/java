package javaMysqlTest;

import java.sql.SQLException;
import java.util.Scanner;
import util.Db;

public class ProcMenuRead {

	static Scanner sc = new Scanner(System.in);

	static void run() {
		System.out.println("읽을 글 번호를 입력하십시오:");
		String readNo = sc.next();
		try {
			Db.result = Db.st.executeQuery("select *from board where b_no=" + readNo);
			Db.result.next();
			String title = Db.result.getString("b_title");
			String id = Db.result.getString("b_id");
			String corrector = Db.result.getString("b_corrector");
			String text = Db.result.getString("b_text");
			int hit = Db.result.getInt("b_hit");
			hit=hit+1;
			System.out.println("글제목: " + title);
			System.out.println("작성자: " + id);
			System.out.println("편집자: " + corrector);
			System.out.println("글내용: " + text);
			System.out.println("조회수: " + hit);
			Db.dbExecuteUpdate("update board set b_hit =" +hit+ " where b_no=" + readNo);
			
			ProcMenuReply.list(Integer.parseInt(readNo));// 읽은 글 댓글리스트 출력
			loop: while (true) {
				System.out.println("명령[x:나가기 / r:댓글작성]");
				String cmd = sc.next();
				switch (cmd) {
				case "x":
					break loop;
				case "r":
					ProcMenuReply.write(Integer.parseInt(readNo));
					break;
				default:
					System.out.println("잘못된 입력입니다.");
				}
			}
		} catch (SQLException e) {// 예외처리
//			e.printStackTrace();// 에러의 발생근원지를 찾아서 단계별로 에러를 출력
			System.out.println("없는 글 번호 입니다.");
		}

	}

}
