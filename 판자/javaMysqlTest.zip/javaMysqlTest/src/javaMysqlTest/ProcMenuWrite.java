package javaMysqlTest;

import java.sql.SQLException;
import java.util.Scanner;
import util.Db;

public class ProcMenuWrite {

	static Scanner sc = new Scanner(System.in);

	static void run() {
		System.out.println("[1.글쓰기/2.뒤로가기]");//메뉴를 잘못 들어온경우
		String cmd = sc.nextLine();
		switch (cmd) {
		case "1":
			System.out.println("제목을 입력하십시오:");
			String title = sc.nextLine();
			System.out.println("작성자 id를 입력하십시오:");
			String id = sc.next();
			sc.nextLine();// 중간에 남은 코드 정리용
			System.out.println("내용을 입력하십시오:");
			String text = sc.nextLine();//
			try {
				Db.st.executeUpdate("insert into board (b_title,b_id,b_datetime,b_text,b_hit)" + " values ('" + title
						+ "','" + id + "',now(),'" + text + "',0)");
				System.out.println("글등록 완료");
			} catch (SQLException e) {
				e.printStackTrace();
			}
		case "2":
			System.out.println("뒤로 돌아갑니다.");
			break;
		}
	}

}
