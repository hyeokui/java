package javaMysqlTest;

import java.util.Scanner;
import util.Db;

public class ProcMenuDel {

	static Scanner sc = new Scanner(System.in);

	static void run() {
		System.out.println("[1.삭제하기/2.뒤로가기]");
		String cmd = sc.next();
		switch (cmd) {
		case "1":
			System.out.println("삭제 할 글 번호를 입력하십시오: ");
			String delNo = sc.next();
			System.out.println("비밀번호를 입력하십시오: ");
			String delPw = sc.next();
			if (delPw.equals("root")) {

				Db.dbExecuteUpdate("delete from board where b_no=" + delNo);
			} else {
				System.out.println("잘못된 비밀번호입니다.");
			}break;
		case "2":
			System.out.println("뒤로 돌아갑니다.");
			break;
		}

	}
}