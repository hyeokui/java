package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Db {
	static private String DB_NAME = "my_cat";
	static private String DB_ID = "root";
	static private String DB_PW = "root";
	static public Connection con = null;
	static public Statement st = null;
	static public ResultSet result = null;

	static public void dbInit() {
		try {
			Db.con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + DB_NAME, DB_ID, DB_PW);
			Db.st = Db.con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet
												// 객체만을 열 수있다.
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	static public void dbExecuteUpdate(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			if (resultCount == 0) {
				System.out.println("입력오류입니다.");
			} else {
				System.out.println("처리된 행 수:" + resultCount);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	static public void dbPostCount() {
		try {
			Db.result = Db.st.executeQuery("select count(*) from board");
			Db.result.next();
			String count = Db.result.getString("count(*)");
			System.out.println("글 수:" + count);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	static public int getPostCount() {
		String count = "";
		try {
			Db.result = Db.st.executeQuery("select count(*) from board");
			Db.result.next();
			count = Db.result.getString("count(*)");
//			System.out.println("글 수:"+count);  
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}

	public static int getPostCountSearch(String searchWord) {
		String count = "";
		try {
			Db.result = Db.st.executeQuery("select count(*) from board where b_title like '%" + searchWord + "%'");
			Db.result.next();
			count = Db.result.getString("count(*)");
			System.out.println("글 수:" + count);
		} catch (Exception e) {
		}
		int intCount = Integer.parseInt(count);
		return intCount;
	}
}
