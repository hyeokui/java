/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module javaMysqlTest {
	requires java.sql;
}