/**
 * 
 */
/**
 * @author GDJ59
 *
 */
module HelloWorld {
}